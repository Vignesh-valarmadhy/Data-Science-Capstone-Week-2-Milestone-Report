# Milestone Report of Coursera's Data Science Capstone 

Here it can be find the ***R Markdown*** source code (***milestone-report.Rmd***) for generating the ***Milestone Report*** of [***Data Science Capstone***](https://www.coursera.org/learn/data-science-project).
